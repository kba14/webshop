const cartIcon = document.querySelector('.cart_icon');
const cartElement = document.querySelector('.cart_container');
const cartItemsList = document.querySelector('.cart_items');

cartIcon.addEventListener('click', () => {
    // Fetch current cart contents from server
    fetch('http://127.0.0.1:3142/cart')
        .then(response => {
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          return response.text();
        })
        .then(text => {
          let cart;
          try {
            cart = JSON.parse(text);
          }
          catch (error) {
            console.error(error);
            //return;
          }

            // Update cart count
            let totalQuantity = 0;
            for (const item in cart) {
              if (cart.hasOwnProperty(item)) {
                totalQuantity += cart[item].quantity;
              }
            }
            const cartCount = document.querySelector('.cart_count');
            cartCount.textContent = `${totalQuantity}`;

            // Clear cart items list
            cartItemsList.innerHTML = '';

            if (cart) {
              // Create and append new cart items for each element in cart
              for (const itemKey in cart) {
                if (Object.hasOwnProperty.call(cart, itemKey)) {
                  const item = cart[itemKey];
                  console.log(item);

                  // Create new cart item element
                  const cartItemElement = document.createElement('li');
                  cartItemElement.classList.add('cart_item');

                  // Create new cart item name element
                  const cartItemNameElement = document.createElement('div');
                  cartItemNameElement.classList.add('cart_item_name');
                  cartItemNameElement.textContent = item.name;

                  // Create new cart item quantity element
                  const cartItemQuantityElement = document.createElement('div');
                  cartItemQuantityElement.classList.add('cart_item_quantity');
                  cartItemQuantityElement.textContent = `Quantity: ${item.quantity}`;

                  // Append cart item name and quantity element to cart item element
                  cartItemElement.appendChild(cartItemNameElement);
                  cartItemElement.appendChild(cartItemQuantityElement);

                  // Append cart item element to cart items list
                  cartItemsList.appendChild(cartItemElement);
                }
              }
            }

            // Display cart element
            cartElement.classList.toggle('show');
        })
        .catch(error => console.error(error));
});


// Get the "Add to cart" buttons
const addToCartButtons = document.querySelectorAll('.add_to_cart_button');

// Add an event listener to each "Add to cart" button
addToCartButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Get the product ID from the button's data attribute
    const itemId = button.dataset.itemId;

    // Send a POST request to the server to add the item to the cart
    fetch(`http://127.0.0.1:3142/cart/add/${itemId}`, {
      method: 'POST'
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    })
    .then(updatedCart => {
      // Handle the server response here
      console.log(updatedCart);
    })
    .catch(error => console.error(error));
  });
});